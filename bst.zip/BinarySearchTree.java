import java.util.Comparator;

import LinkedListStack.LinkedStack;
import queues.*;
import java.util.Iterator;

// 1. T extends Comparable<T> means:
//    - T is a generic type parameter that represents the type of data stored in the tree
//    - "extends Comparable<T>" is a constraint that requires T to implement the Comparable interface
//    - This ensures that objects of type T can be compared to each other using compareTo()
//    - This is necessary for a BST because we need to order elements (left < parent < right)
public class BinarySearchTree<T extends Comparable<T>> implements BSTInterface<T>{
    protected BSTNode<T> root;
    // 2. A Comparator is an interface from java.util that defines how to compare two objects
    //    - It has a compare(T o1, T o2) method that returns:
    //      * negative number if o1 < o2
    //      * zero if o1 == o2
    //      * positive number if o1 > o2
    //    - Comparators allow us to define custom ordering logic separate from the object's natural ordering
    protected Comparator<T> comp;

    protected boolean found;

    public BinarySearchTree()
    {
        root=null;
        
        // 3. When we set comp = new Comparator<T>() {...}, we are:
        //    - Creating an anonymous inner class that implements the Comparator interface
        //    - Defining the compare() method inline to use the object's natural ordering
        //    - This implementation simply delegates to the compareTo() method from Comparable
        //    - This provides a default comparison strategy when no custom Comparator is provided
        comp = new Comparator<T>(){
            public int compare(T element1, T element2){
                return ((Comparable<T>)element1).compareTo(element2);
            }
        };
    }
    
    // 4. Passing a Comparator into the constructor allows:
    //    - Custom ordering of elements in the tree (e.g., reverse order, case-insensitive strings)
    //    - Flexibility to sort objects without modifying their class or natural ordering
    //    - The ability to create multiple trees with different orderings for the same type
    //    - Example: You could sort Strings alphabetically in one tree and by length in another
    public BinarySearchTree(Comparator<T> comp){
        root = null;
        this.comp = comp;
    }

    public boolean isFull()
    {
        return false;
    }
    public boolean isEmpty(){
        return root==null;
    }
    //The minimum element in a BST is always going to be the leftmost element in the tree. 
    // This is a result of the binary search property
    // elements to the left are less than or equal to their ancestors
    public T min(){
        if (isEmpty()){
            return null;
        }
        BSTNode<T> node = root;
        while(node.getLeft()!=null){
            node=node.getLeft();
        }
        return node.getInfo();
    }
    // Maximum element is the rightmost element
    // result of binary search property
    // elements to the right are always greater than their ancestors
    public T max(){
        if (isEmpty()){
            return null;
        }
        BSTNode<T> node = root;
        while(node.getRight()!=null){
            node=node.getRight();
        }
        return node.getInfo();
    }
    public Integer size(){
        return recSize(root);
    }

    private int recSize(BSTNode<T> node) {
        if (node == null){
            return 0;
        }
        else {
            return 1 + recSize(node.getLeft()) + recSize(node.getRight());
        }
    }

    private int iterSize(BSTNode<T> node){
        int count=0;
        if(node!=null){
            LinkedStack<BSTNode<T>> nodeStack = new LinkedStack<BSTNode<T>>();
            BSTNode<T> currNode;
            nodeStack.push(node);
            while(!nodeStack.isEmpty()){

            }
        }
        return count;
    }
    
    public boolean contains (T Target){
        return recContains(Target, root);
    }

    private boolean recContains(T target, BSTNode<T> node){
        if(node==null){
            return false;
        }
        if(comp.compare(target, node.getInfo())<0){
            return recContains(target, node.getLeft());
        }
        if(comp.compare(target, node.getInfo())>0){
            return recContains(target, node.getRight());
        }
        return true;
    }

    public T get(T target){
        return recGet(target, root);
    }
    private T recGet(T target, BSTNode<T> node){
        if(node==null){
            return null;
        }
        if(comp.compare(target, node.getInfo())<0){
            recGet(target, node.getLeft());
        }
        if(comp.compare(target, node.getInfo())>0){
            recGet(target, node.getRight());
        }
        return node.getInfo();

    }

    public Iterator<T> getIterator(BSTInterface.Traversal orderType){
        //Goal: Create and returns an Iterator providing a traversal of a "snapshot" of the current tree in the order indicated by the argument
        //support preorder, postorder,inorder traversal
        final LinkedQueue<T> infoQueue = new LinkedQueue<T>();

    }

}
